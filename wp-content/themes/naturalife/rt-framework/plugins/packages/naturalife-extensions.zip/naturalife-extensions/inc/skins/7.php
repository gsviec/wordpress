<?php
	$skin_data = array(
		"naturalife_overlapped_header" => "", 
		"naturalife_display_main_menu" => "1",

		"naturalife_header_sidepanel" => "1",
		"naturalife_header_sidepanel_mobile" => "1",

		"naturalife_header_wpml" => "1",
		"naturalife_header_search" => "1",
		"naturalife_header_cart" => "1",
		"naturalife_header_user" => "1",

		"naturalife_header_width" => "default",
		"naturalife_header_style" => "2",

		"naturalife_header_height_single" => "70",
		"naturalife_header_height_first" => "60",
		"naturalife_header_height_second" => "40",
		"naturalife_header_vertical_padding" => "15",

		"naturalife_header_color_skin" => "dark",
		"naturalife_header_bg_color" => "#ffffff",
		
		"naturalife_header_logo_location" => "2",
		"naturalife_header_menu_location" => "4",
		"naturalife_header_icon_location" => "3", 

		"naturalife_sticky_header_logo_location" => "1",
		"naturalife_sticky_header_menu_location" => "1",
		"naturalife_sticky_header_icon_location" => "3",  

		"naturalife_sub_header_top_padding"	=> "60",
		"naturalife_sub_header_bottom_padding" => "60",		
	);
?>